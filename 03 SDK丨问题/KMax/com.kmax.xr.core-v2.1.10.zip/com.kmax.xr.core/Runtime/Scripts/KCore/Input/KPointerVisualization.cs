﻿////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2007-2020 zSpace, Inc.  All Rights Reserved.
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;

namespace KmaxXR.Core
{
    public class KPointerVisualization : MonoBehaviour
    {
        public virtual void Process(KPointer pointer, float worldScale)
        {
        }
    }
}
