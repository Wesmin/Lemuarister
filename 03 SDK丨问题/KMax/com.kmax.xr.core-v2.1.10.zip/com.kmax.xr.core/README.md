﻿# Kmax XR Core

在 Kmax M1, K1 上提供了立体显示和触笔交互支持。
Support Stereo Display and stylus input on Kmax XR devices.

## 主要模块 Main component

主要包含了立体显示及空间交互。

### XRRig

立体显示和视口相关。

### PadTracker

笔眼追踪，是立体显示和空间交互的基础。

### KmaxInputModule

提供空间交互支持。
