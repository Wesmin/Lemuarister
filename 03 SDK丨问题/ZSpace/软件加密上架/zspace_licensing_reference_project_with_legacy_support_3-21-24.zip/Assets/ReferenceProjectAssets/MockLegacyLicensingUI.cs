using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using zSpace.Core.Input;
using zSpace.Licensing.Unity;

public class MockLegacyLicensingUI : MonoBehaviour
{
    public GameObject ui;
    public Text legacyStatusText;
    public Button activateButton;
    public Button deactivateButton;
    public Text closeActionStatusText;
    public Button closeButton;

    public string proceedToScene = "";

    public void Awake()
    {
        UpdateStatusTexts();

        activateButton.onClick.AddListener(() => {
            MockLegacyLicensing.SetActivationStatus(true);
            UpdateStatusTexts();
        });

        deactivateButton.onClick.AddListener(() => { 
            MockLegacyLicensing.SetActivationStatus(false);
            UpdateStatusTexts();
        });

        closeButton.onClick.AddListener(() => { 
            if(MockLegacyLicensing.IsActivated())
            {
                // if this is the startup splash scene, proceed to the main scene
                if (proceedToScene != "")
                {
                    UnityEngine.SceneManagement.SceneManager.LoadScene(proceedToScene);
                }
                // if we're already in the main scene, then restore interactivity
                // and hide this licensing UI
                else
                {
                    LicensingInteractionBlocker.RestoreInteractivity();
                    this.gameObject.SetActive(false);
                }
            }
            else
            {
                Application.Quit();
            }   
        });
    }

    private void UpdateStatusTexts()
    {
        bool legacyActivated = MockLegacyLicensing.IsActivated();

        if(legacyActivated)
        {
            legacyStatusText.text = "Legacy License Activated";
            closeActionStatusText.text = "App is activated, Closing will return to app.";
        }
        else
        {
            legacyStatusText.text = "Legacy License Not Activated";
            closeActionStatusText.text = "No active license, Closing will quit app.";
        }
    }
}
