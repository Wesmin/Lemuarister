using UnityEngine;
using zSpace.Core.Input;

// This script is here to demonstrate a basic means of blocking interactivity
// while a licensing menu is open. It is not required to be done in this specific
// way, and it is assumed that the pre-existing legacy licensing system already
// has an equivalent means of doing this.

public class LicensingInteractionBlocker : MonoBehaviour
{

    private static LayerMask licensingMask;
    
    public static LicensingInteractionBlocker instance;

    private static LayerMask mouseCachedMask;
    private static LayerMask stylusCachedMask;

    private static bool isBlocking = false;

    private ZMouse mouse;
    private ZStylus stylus;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this);
        }

        // Set up a mask that ignores everything but the legacy licensing UI.
        licensingMask = ~(LayerMask.GetMask("Licensing UI"));

        mouse = FindObjectOfType<ZMouse>();
        stylus = FindObjectOfType<ZStylus>();
    }

    public static void BlockInteractivity()
    {
        if(instance == null || isBlocking)
        {
            return;
        }

        isBlocking = true;
        mouseCachedMask = LicensingInteractionBlocker.instance.mouse.IgnoreMask;
        stylusCachedMask = LicensingInteractionBlocker.instance.stylus.IgnoreMask;
        LicensingInteractionBlocker.instance.mouse.IgnoreMask = licensingMask;
        LicensingInteractionBlocker.instance.stylus.IgnoreMask = licensingMask;
    }

    public static void RestoreInteractivity()
    {
        if(instance == null || !isBlocking)
        {
            return;
        }

        isBlocking = false;
        LicensingInteractionBlocker.instance.mouse.IgnoreMask = mouseCachedMask;
        LicensingInteractionBlocker.instance.stylus.IgnoreMask = stylusCachedMask;
    }
}
