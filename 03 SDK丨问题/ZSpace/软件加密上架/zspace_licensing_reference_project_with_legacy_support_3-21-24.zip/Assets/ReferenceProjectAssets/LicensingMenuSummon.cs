using System;
using UnityEngine;
using UnityEngine.UI;
using zSpace.Licensing.Unity;
using zSpace;
using zSpace.Core.Input;
using UnityEngine.Rendering;

public class LicensingMenuSummon : MonoBehaviour
{
    private LayerMask stylusIgnoreMaskCached;
    private LayerMask mouseIgnoreMaskCached;

    private ZStylus stylus;
    private ZMouse mouse;

    public GameObject mockLegacyLicensingUI;

    void Start()
    {
        stylus = GameObject.FindObjectOfType<ZStylus>();
        mouse = GameObject.FindObjectOfType<ZMouse>();

        Button button = this.GetComponent<Button>();

        LicensingUtility.ShowLicenseManagementUiCompletionFunc callback =
            OnLicensingManagementCompletion;

        button.onClick.AddListener(()=> {
            LicensingInteractionBlocker.BlockInteractivity();

            if (MockLegacyLicensing.IsActivated())
            {
                mockLegacyLicensingUI.SetActive(true);
            }
            else
            {
                LicensingUtility.ShowLicenseManagementUi(callback);
            }
        });

    }

    void OnLicensingManagementCompletion(Exception exception, bool shouldExit)
    {
        if(exception != null)
        {
            Debug.LogError(exception);
        }

        if(shouldExit)
        {
            Debug.Log("License Management Exiting application");
            Application.Quit();
        }else{
            LicensingUtility.GetLastShouldUseLegacyLicensingSystemResult(
                (exception, shouldUseLegacyLicensingSystem) =>
                {
                    if(shouldUseLegacyLicensingSystem)
                    {
                        Debug.Log("Summoning legacy licensing");
                        mockLegacyLicensingUI.SetActive(true);
                    }
                    else
                    {
                        Debug.Log("zSpace License Check Passed");
                        LicensingInteractionBlocker.RestoreInteractivity();
                    }
                }
            );
        }   
    }
}
