using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MockLegacyLicensing : MonoBehaviour
{
    // This script is here to imitate a hypothetically pre-existing
    // licensing system, and is not intended to be used in final
    // production code.

    public static bool IsActivated()
    {
        return PlayerPrefs.GetInt("LegacyLicenseActivationStatus") == 1;
    }

    public static void SetActivationStatus(bool status)
    {
        PlayerPrefs.SetInt("LegacyLicenseActivationStatus", status ? 1 : 0);
    }
}
