using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using zSpace.Licensing.Unity;

public class LicensingTestScript : MonoBehaviour
{
    public GameObject mockLegacyLicensingUI;

    void Start()
    {
        // If there is a an activated legacy license, don't check the zSpace
        // license, and proceed to the main scene.
        if(MockLegacyLicensing.IsActivated())
        {
            SceneManager.LoadScene("ContentBehindLicensingWall");
            return;
        }

        ApplicationLicensingConfiguration config = new ApplicationLicensingConfiguration();

        config.SetApplicationActiveModeId("Your app's Mode ID");
        config.SetApplicationVersion(Application.version);
        config.SetApplicationLicensingSecret("Your App's licensing Secret");

        // by writing "./ApplicationLicensingDetails.dat" as the argument for the following method,
        // the file is expected to be located in Assets/StreamingAssets/ApplicationLicensingDetails.dat
        config.SetApplicationLicensingDetailsFromStreamingAssetsFile("./ApplicationLicensingDetails.dat");

    
        // The following call is given static values for the overall simplicity of this sample project.
        //
        // If your app has a means of being localized in multiple languages, be sure to integrate this call and
        // specify a locale and name according to the current language.
        config.SetLocale("en-US", "user facing app name");

        config.SetLegacyLicensingSystemSupportEnabled(true);

        LicensingUtility.InitializeLicensingAndCheckLicenseCompletionFunc handler =
            StartUpLicenseCheckCallback;

        LicensingUtility.InitializeLicensingAndCheckLicense(config, handler);

        // If the app does this check at a point where the app is already interactable,
        // rather than on a splash scene, then the app should momentarily block
        // interactivity here until the license check has completed.
    }

    void StartUpLicenseCheckCallback(Exception exception, bool shouldExit)
    {
        if(exception != null)
        {
            Debug.LogError(exception);
        }

        if(shouldExit)
        {
            Debug.Log("License Check Exiting application");
            Application.Quit();
        }else{
            LicensingUtility.GetLastShouldUseLegacyLicensingSystemResult(
                (exception, shouldUseLegacyLicensingSystem) =>
                {
                    if(shouldUseLegacyLicensingSystem)
                    {
                        Debug.Log("Summon legacy licensing");
                        
                        mockLegacyLicensingUI.SetActive(true);
                    }
                    else
                    {
                        Debug.Log("zSpace License Check Passed");
                        SceneManager.LoadScene("ContentBehindLicensingWall");
                    }
                }
            );
        }   
    }
}
