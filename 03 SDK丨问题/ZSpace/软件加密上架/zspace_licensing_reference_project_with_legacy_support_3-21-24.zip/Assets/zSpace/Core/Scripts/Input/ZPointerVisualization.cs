﻿////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2007-2020 zSpace, Inc.  All Rights Reserved.
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;

namespace zSpace.Core.Input
{
    public class ZPointerVisualization : MonoBehaviour
    {
        public virtual void Process(ZPointer pointer, Vector3 worldScale)
        {
        }
    }
}
