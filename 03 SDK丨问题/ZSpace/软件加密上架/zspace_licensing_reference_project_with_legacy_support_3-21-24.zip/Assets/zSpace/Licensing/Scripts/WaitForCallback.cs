﻿//////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2007-2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////

using System.Collections;

namespace zSpace.Licensing.Unity
{
    /// <summary>
    /// Custom Unity coroutine yield instruction that waits until it is told
    /// that a callback has been called.
    /// </summary>
    /// <remarks>
    /// This is intended to be used to wait for a callback to be called from
    /// within a Unity coroutine.
    /// </remarks>
    public class WaitForCallback : IEnumerator
    {
        //////////////////////////////////////////////////////////////////
        // Public Methods
        //////////////////////////////////////////////////////////////////

        public void SetCallbackCalled()
        {
            this._wasCallbackCalled = true;
        }

        //////////////////////////////////////////////////////////////////
        // IEnumerator Members
        //////////////////////////////////////////////////////////////////

        public object Current
        {
            get
            {
                return null;
            }
        }

        public bool MoveNext()
        {
            return !this._wasCallbackCalled;
        }

        public void Reset()
        {
            // Empty function.
        }

        //////////////////////////////////////////////////////////////////
        // Private Members
        //////////////////////////////////////////////////////////////////

        private bool _wasCallbackCalled = false;
    }
}
