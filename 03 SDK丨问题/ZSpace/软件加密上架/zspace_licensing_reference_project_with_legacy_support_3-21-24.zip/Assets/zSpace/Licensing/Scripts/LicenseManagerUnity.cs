﻿//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////////

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
# define ZSPACE_LICENSING_AVAILABLE
#endif

#if !UNITY_EDITOR || ZSPACE_LICENSING_ENABLE_IN_UNITY_EDITOR
# define ZSPACE_LICENSING_ENABLED
#endif

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

using UnityEngine;

namespace zSpace.Licensing.Unity
{
    public class LicenseManagerUnity : MonoBehaviour
    {
        //////////////////////////////////////////////////////////////////
        // Public Properties
        //////////////////////////////////////////////////////////////////

        public bool IsInitialized
        {
            get
            {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
                return this._licenseManager != null;
# else // ZSPACE_LICENSING_ENABLED
                return this._isInitialized;
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
                return false;
#endif // ZSPACE_LICENSING_AVAILABLE
            }
        }

        //////////////////////////////////////////////////////////////////
        // Public Methods
        //////////////////////////////////////////////////////////////////

        public delegate void InitializeCompletionFunc(Exception exception);

        public void Initialize(
            ApplicationLicensingConfiguration
                applicationLicensingConfiguration,
            InitializeCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
            VerifyApplicationLicensingConfiguration(
                applicationLicensingConfiguration);

# if ZSPACE_LICENSING_ENABLED
            if (this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity already initialized"));
                    });
            }

            var clientLogFunc = applicationLicensingConfiguration.LogFunc;

            LicenseManager.LogFunc licenseManagerLogFunc = null;

            if (clientLogFunc != null)
            {
                licenseManagerLogFunc =
                    (
                        licenseManagerLogLevel,
                        timestamp,
                        loggerName,
                        threadId,
                        message) =>
                    {
                        clientLogFunc(
                            ConvertLicenseManagerLogLevelToUnityLicensingLogLevel(
                                licenseManagerLogLevel),
                            timestamp,
                            loggerName,
                            threadId,
                            message);
                    };
            }

            var applicationMainWindowHandle = IntPtr.Zero;

            if (applicationLicensingConfiguration.ApplicationMainWindowHandle
                .HasValue)
            {
                applicationMainWindowHandle =
                    applicationLicensingConfiguration
                        .ApplicationMainWindowHandle.Value;
            }
            else
            {
                zlicuGetApplicationMainWindowHandle(
                    out applicationMainWindowHandle);
            }

            var shouldEnableLegacyLicensingSystemSupport =
                applicationLicensingConfiguration
                    .ShouldEnableLegacyLicensingSystemSupport;

            this._licenseManager = LicenseManager.Create(
                logFunc: licenseManagerLogFunc,
                logLevel:
                    ConvertUnityLicensingLogLevelToLicenseManagerLogLevel(
                        applicationLicensingConfiguration.LogLevel),
                applicationActiveModeIds:
                    applicationLicensingConfiguration.ApplicationActiveModeIds,
                applicationActiveSupplementIds:
                    applicationLicensingConfiguration
                        .ApplicationActiveSupplementIds,
                applicationVersion:
                    applicationLicensingConfiguration.ApplicationVersion,
                applicationLicensingSecretBytes:
                    applicationLicensingConfiguration
                        .ApplicationLicensingSecretBytes,
                applicationLicensingDetailsBytes:
                    applicationLicensingConfiguration
                        .ApplicationLicensingDetailsBytes,
                locale: applicationLicensingConfiguration.Locale,
                applicationUserFriendlyNameForLocale:
                    applicationLicensingConfiguration.
                        ApplicationUserFriendlyNameForLocale,
                applicationMainWindowHandle: applicationMainWindowHandle,
                completionFunc:
                    (exception) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                this.HandleLicenseManagerCreationCompletion(
                                    exception,
                                    shouldEnableLegacyLicensingSystemSupport,
                                    completionCallback);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            this._isInitialized = true;

            if (applicationLicensingConfiguration
                    .ApplicationActiveSupplementIds !=
                null)
            {
                this._applicationActiveSupplementIds =
                    applicationLicensingConfiguration
                        .ApplicationActiveSupplementIds;
            }
            else
            {
                this._applicationActiveSupplementIds = new string[0];
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"));
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void SetLocaleCompletionFunc(Exception exception);

        public void SetLocale(
            string locale,
            string applicationUserFriendlyNameForLocale,
            SetLocaleCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"));
                    });

                return;
            }

            this._licenseManager.SetLocale(
                    locale,
                    applicationUserFriendlyNameForLocale,
                    (exception) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(exception);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"));
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"));
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void CheckLicenseCompletionFunc(
            Exception exception, bool shouldExit);

        public void CheckLicense(
            CheckLicenseCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            true);
                    });

                return;
            }

            this._licenseManager.CheckLicense(
                    (exception, shouldExit) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(exception, shouldExit);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            true);
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null, false);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"),
                        true);
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void ShowLicenseManagementUiCompletionFunc(
            Exception exception, bool shouldExit);

        public void ShowLicenseManagementUi(
            ShowLicenseManagementUiCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            true);
                    });

                return;
            }

            this._licenseManager.ShowLicenseManagementUi(
                    (exception, shouldExit) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(exception, shouldExit);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            true);
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null, false);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"),
                        true);
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void GetValidSupplementIdsCompletionFunc(
            Exception exception, string[] validSupplementIds);

        public void GetValidSupplementIds(
            GetValidSupplementIdsCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            null);
                    });

                return;
            }

            this._licenseManager.GetValidSupplementIds(
                    (exception, validSupplementIds) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(
                                    exception, validSupplementIds);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            null);
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(
                       null, this._applicationActiveSupplementIds);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"),
                        null);
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void CheckIsUsingZspaceLicensingSystemCompletionFunc(
            Exception exception, bool isUsingZspaceLicensingSystem);

        public void CheckIsUsingZspaceLicensingSystem(
            CheckIsUsingZspaceLicensingSystemCompletionFunc completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            false);
                    });

                return;
            }

            this._licenseManager.CheckIsUsingZspaceLicensingSystem(
                    (exception, isUsingZspaceLicensingSystem) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(
                                    exception, isUsingZspaceLicensingSystem);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            false);
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null, false);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"),
                        false);
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        public delegate void
            GetLastShouldUseLegacyLicensingSystemResultCompletionFunc(
                Exception exception, bool shouldUseLegacyLicensingSystem);

        public void GetLastShouldUseLegacyLicensingSystemResult(
            GetLastShouldUseLegacyLicensingSystemResultCompletionFunc
                completionCallback)
        {
#if ZSPACE_LICENSING_AVAILABLE
# if ZSPACE_LICENSING_ENABLED
            if (!this.IsInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            false);
                    });

                return;
            }

            this._licenseManager.GetLastShouldUseLegacyLicensingSystemResult(
                    (exception, shouldUseLegacyLicensingSystem) =>
                    {
                        this.EnqueueCallback(
                            () =>
                            {
                                completionCallback(
                                    exception, shouldUseLegacyLicensingSystem);
                            });
                    });
# else // ZSPACE_LICENSING_ENABLED
            if (!this._isInitialized)
            {
                this.EnqueueCallback(
                    () =>
                    {
                        completionCallback(
                            new Exception(
                                "LicenseManagerUnity not initialized"),
                            false);
                    });

                return;
            }

            this.EnqueueCallback(
               () =>
               {
                   completionCallback(null, false);
               });
# endif // ZSPACE_LICENSING_ENABLED
#else // ZSPACE_LICENSING_AVAILABLE
            this.EnqueueCallback(
                () =>
                {
                    completionCallback(
                        new Exception(
                            "zSpace licensing not available for current " +
                                "platform/build configuration"),
                        false);
                });
#endif // ZSPACE_LICENSING_AVAILABLE
        }

        //////////////////////////////////////////////////////////////////
        // MonoBehaviour Callbacks
        //////////////////////////////////////////////////////////////////

        void Start()
        {
            // Empty function.
        }

        void Update()
        {
            this.ProcessPendingCallbacks();
        }

        void OnDestroy()
        {
#if ZSPACE_LICENSING_AVAILABLE
            if (this._licenseManager != null)
            {
                this._licenseManager.Dispose();

                this._licenseManager = null;
            }
#endif // ZSPACE_LICENSING_AVAILABLE

            // Process any pending callbacks in order to unblock client code
            // that may be waiting for a callback.
            //
            // Note:  Because the license manager has already been disposed
            // (see above), no additional callbacks should be enqueued at this
            // point.
            this.ProcessPendingCallbacks();
        }

        //////////////////////////////////////////////////////////////////
        // Private Methods
        //////////////////////////////////////////////////////////////////

        private static void VerifyApplicationLicensingConfiguration(
            ApplicationLicensingConfiguration config)
        {
            if ((config.ApplicationActiveModeIds == null) ||
                (config.ApplicationActiveModeIds.Length == 0))
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "application active mode ID specified");
            }

            if (config.ApplicationVersion == null)
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "application version specified");
            }

            if (config.ApplicationLicensingSecretBytes == null)
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "application licensing secret specified");
            }

            if (config.ApplicationLicensingDetailsBytes == null)
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "application licensing details specified");
            }

            if (config.Locale == null)
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "locale specified");
            }

            if (config.ApplicationUserFriendlyNameForLocale == null)
            {
                throw new Exception(
                    "Invalid application licensing configuration: No " +
                        "application user-friendly name for locale specified");
            }
        }

#if ZSPACE_LICENSING_AVAILABLE
        private static LicenseManager.LogLevel
            ConvertUnityLicensingLogLevelToLicenseManagerLogLevel(
                LicensingLogLevel logLevel)
        {
            return (LicenseManager.LogLevel)logLevel;
        }

        private static LicensingLogLevel
            ConvertLicenseManagerLogLevelToUnityLicensingLogLevel(
                LicenseManager.LogLevel logLevel)
        {
            return (LicensingLogLevel)logLevel;
        }

        [DllImport(
            NativePluginDllFileName32,
            CallingConvention = CallingConvention.StdCall,
            EntryPoint = "zlicuGetApplicationMainWindowHandle")]
        private static extern void zlicuGetApplicationMainWindowHandle32(
            out IntPtr applicationMainWindowHandle);

        [DllImport(
            NativePluginDllFileName64,
            CallingConvention = CallingConvention.StdCall,
            EntryPoint = "zlicuGetApplicationMainWindowHandle")]
        private static extern void zlicuGetApplicationMainWindowHandle64(
            out IntPtr applicationMainWindowHandle);

        private static void zlicuGetApplicationMainWindowHandle(
            out IntPtr applicationMainWindowHandle)
        {
            if (Is64BitProcess)
            {
                zlicuGetApplicationMainWindowHandle64(
                    out applicationMainWindowHandle);
            }
            else
            {
                zlicuGetApplicationMainWindowHandle32(
                    out applicationMainWindowHandle);
            }
        }

        private void HandleLicenseManagerCreationCompletion(
            Exception exception,
            bool shouldEnableLegacyLicensingSystemSupport,
            InitializeCompletionFunc initializeCompletionCallback)
        {
            if (exception != null)
            {
                initializeCompletionCallback(exception);

                return;
            }

            if (this._licenseManager == null)
            {
                // If the license manager is null, that indicates that the
                // Unity license manager has been destroyed and therefore no
                // additional licensing work should be performed (and, in
                // particular, no additional callbacks should be enqueued).
                // Call the initialize completion callback to unblock client
                // code that may be waiting for this callback.
                initializeCompletionCallback(
                    new Exception(
                        "License manager destroyed before creation " +
                            "completion callback called"));

                return;
            }

            if (shouldEnableLegacyLicensingSystemSupport)
            {
                try
                {
                    this._licenseManager.SetLegacyLicensingSystemSupportEnabled(
                        shouldEnableLegacyLicensingSystemSupport,
                        (setLegacyLicensingSystemSupportEnabledException) =>
                        {
                            this.EnqueueCallback(
                                () =>
                                {
                                    initializeCompletionCallback(
                                        setLegacyLicensingSystemSupportEnabledException);
                                });
                        });
                }
                catch (
                    Exception setLegacyLicensingSystemSupportEnabledException)
                {
                    this.EnqueueCallback(
                        () =>
                        {
                            initializeCompletionCallback(
                                setLegacyLicensingSystemSupportEnabledException);
                        });
                }
            }
            else
            {
                initializeCompletionCallback(null);
            }
        }

#endif // ZSPACE_LICENSING_AVAILABLE

        private void EnqueueCallback(Action callback)
        {
            lock (this._pendingCallbacksMutex)
            {
                this._pendingCallbacksQueue.Enqueue(callback);

                Interlocked.Exchange(ref this._hasPendingCallbacks, 1);
            }
        }

        private void ProcessPendingCallbacks()
        {
            var hasPendingCallbacks =
                Interlocked.Exchange(ref this._hasPendingCallbacks, 0);

            if (hasPendingCallbacks == 0)
            {
                return;
            }

            lock (this._pendingCallbacksMutex)
            {
                var prevProcessingCallbacksQueue =
                    this._processingCallbacksQueue;
                this._processingCallbacksQueue = this._pendingCallbacksQueue;
                this._pendingCallbacksQueue = prevProcessingCallbacksQueue;
            }

            while (this._processingCallbacksQueue.Count > 0)
            {
                var callback = this._processingCallbacksQueue.Dequeue();

                try
                {
                    callback();
                }
                catch (Exception e)
                {
                    Debug.LogError(
                        "Exception thrown while calling " +
                            "LicensingManagerUnity callback on Unity main " +
                            "thread:");
                    Debug.LogException(e);
                }
            }
        }

        //////////////////////////////////////////////////////////////////
        // Private Members
        //////////////////////////////////////////////////////////////////

#if ZSPACE_LICENSING_AVAILABLE
        private const string NativePluginDllFileName32 =
            "zSpaceLicensingUnity32";
        private const string NativePluginDllFileName64 =
            "zSpaceLicensingUnity64";

        private static readonly bool Is64BitProcess = IntPtr.Size == 8;
#endif // ZSPACE_LICENSING_AVAILABLE

        private int _hasPendingCallbacks = 0;
        private object _pendingCallbacksMutex = new object();

        private Queue<Action> _pendingCallbacksQueue = new Queue<Action>();
        private Queue<Action> _processingCallbacksQueue = new Queue<Action>();

#if ZSPACE_LICENSING_AVAILABLE
        private LicenseManager _licenseManager = null;

# if !ZSPACE_LICENSING_ENABLED
        private bool _isInitialized = false;
        private string[] _applicationActiveSupplementIds = null;
# endif // !ZSPACE_LICENSING_ENABLED
#endif // ZSPACE_LICENSING_AVAILABLE
    }
}
