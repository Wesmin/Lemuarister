//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using UnityEngine;

namespace zSpace.Licensing.Unity
{
    public static class LicensingUtility
    {
        //////////////////////////////////////////////////////////////////
        // Public Methods
        //////////////////////////////////////////////////////////////////

        public delegate void InitializeLicensingCompletionFunc(
            Exception exception);

        public static void InitializeLicensing(
            ApplicationLicensingConfiguration
                applicationLicensingConfiguration,
            InitializeLicensingCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity != null)
            {
                completionCallback(
                    new Exception("Licensing already initialized"));

                return;
            }

            try
            {
                s_licenseManagerGameObject = new GameObject("LicenseManager");
                GameObject.DontDestroyOnLoad(s_licenseManagerGameObject);

                s_licenseManagerUnity =
                    s_licenseManagerGameObject
                        .AddComponent<LicenseManagerUnity>();
            }
            catch (Exception e)
            {
                if (s_licenseManagerGameObject != null)
                {
                    try
                    {
                        GameObject.Destroy(s_licenseManagerGameObject);
                    }
                    catch (Exception destroyException)
                    {
                        Debug.LogError(
                            "Failed to initialize licensing:  Failed to " +
                                "destroy license manager game object after " +
                                "failure to create license manager.  " +
                                "Exception details:");
                        Debug.LogException(destroyException);
                    }

                    s_licenseManagerGameObject = null;
                    s_licenseManagerUnity = null;
                }

                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to initialize licensing: Failed to " +
                                "create license manager: {0}",
                            e.Message),
                        e));

                return;
            }

            try
            {
                s_licenseManagerUnity.Initialize(
                    applicationLicensingConfiguration,
                    (exception) =>
                    {
                        if (exception != null)
                        {
                            try
                            {
                                GameObject.Destroy(s_licenseManagerGameObject);
                            }
                            catch (Exception destroyException)
                            {
                                Debug.LogError(
                                    "Failed to initialize licensing:  " +
                                        "Failed to destroy license manager " +
                                        "game object after failure to " +
                                        "initialize license manager.  " +
                                        "Exception details:");
                                Debug.LogException(destroyException);
                            }

                            s_licenseManagerGameObject = null;
                            s_licenseManagerUnity = null;
                        }

                        completionCallback(exception);
                    });
            }
            catch (Exception e)
            {
                try
                {
                    GameObject.Destroy(s_licenseManagerGameObject);
                }
                catch (Exception destroyException)
                {
                    Debug.LogError(
                        "Failed to initialize licensing:  Failed to destroy " +
                            "license manager game object after failure to " +
                            "initialize license manager.  Exception details:");
                    Debug.LogException(destroyException);
                }

                s_licenseManagerGameObject = null;
                s_licenseManagerUnity = null;

                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to initialize licensing: Failed to " +
                                "initialize license manager: {0}",
                            e.Message),
                        e));

                return;
            }
        }

        public static IEnumerator InitializeLicensingCoroutineEnumerator(
            ApplicationLicensingConfiguration
                applicationLicensingConfiguration,
            InitializeLicensingCompletionFunc completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            InitializeLicensing(
                applicationLicensingConfiguration,
                (exception) =>
                {
                    completionCallback(exception);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void InitializeLicensingAndCheckLicenseCompletionFunc(
            Exception exception, bool shouldExit);

        public static void InitializeLicensingAndCheckLicense(
            ApplicationLicensingConfiguration
                applicationLicensingConfiguration,
            InitializeLicensingAndCheckLicenseCompletionFunc
                completionCallback)
        {
            InitializeLicensing(
                applicationLicensingConfiguration,
                (initializeLicensingException) =>
                {
                    if (initializeLicensingException != null)
                    {
                        completionCallback(
                            initializeLicensingException,
                            shouldExit: true);

                        return;
                    }

                    CheckLicense(
                        (checkLicenseException, shouldExit) =>
                        {
                            completionCallback(
                                exception: checkLicenseException,
                                shouldExit: shouldExit);
                        });
                });
        }

        public static IEnumerator
            InitializeLicensingAndCheckLicenseCoroutineEnumerator(
                ApplicationLicensingConfiguration
                    applicationLicensingConfiguration,
                InitializeLicensingAndCheckLicenseCompletionFunc
                    completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            InitializeLicensingAndCheckLicense(
                applicationLicensingConfiguration,
                (exception, shouldExit) =>
                {
                    completionCallback(exception, shouldExit);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void SetLocaleCompletionFunc(Exception exception);

        public static void SetLocale(
            string locale,
            string applicationUserFriendlyNameForLocale,
            SetLocaleCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to set licensing locale: Licensing not " +
                            "initialized"));

                return;
            }

            try
            {
                s_licenseManagerUnity.SetLocale(
                    locale,
                    applicationUserFriendlyNameForLocale,
                    (exception) =>
                    {
                        completionCallback(exception);
                    });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to set licensing locale: {0}",
                            e.Message),
                        e));

                return;
            }
        }

        public static IEnumerator SetLocaleCoroutineEnumerator(
            string locale,
            string applicationUserFriendlyNameForLocale,
            SetLocaleCompletionFunc completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            SetLocale(
                locale,
                applicationUserFriendlyNameForLocale,
                (exception) =>
                {
                    completionCallback(exception);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void CheckLicenseCompletionFunc(
            Exception exception, bool shouldExit);

        public static void CheckLicense(
            CheckLicenseCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to check license: Licensing not initialized"),
                    shouldExit: true);

                return;
            }

            try
            {
                s_licenseManagerUnity.CheckLicense(
                    (exception, shouldExit) =>
                    {
                        completionCallback(exception, shouldExit);
                    });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to check license: {0}",
                            e.Message),
                        e),
                    shouldExit: true);

                return;
            }
        }

        public static IEnumerator CheckLicenseCoroutineEnumerator(
            CheckLicenseCompletionFunc completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            CheckLicense(
                (exception, shouldExit) =>
                {
                    completionCallback(exception, shouldExit);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void ShowLicenseManagementUiCompletionFunc(
            Exception exception, bool shouldExit);

        public static void ShowLicenseManagementUi(
            ShowLicenseManagementUiCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to show license management UI: Licensing " +
                            "not initialized"),
                    shouldExit: true);

                return;
            }

            try
            {
                s_licenseManagerUnity.ShowLicenseManagementUi(
                    (exception, shouldExit) =>
                    {
                        completionCallback(exception, shouldExit);
                    });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to show license management UI: {0}",
                            e.Message),
                        e),
                    shouldExit: true);

                return;
            }
        }

        public static IEnumerator ShowLicenseManagementUiCoroutineEnumerator(
            ShowLicenseManagementUiCompletionFunc completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            ShowLicenseManagementUi(
                (exception, shouldExit) =>
                {
                    completionCallback(exception, shouldExit);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void GetValidSupplementIdsCompletionFunc(
            Exception exception, string[] validSupplementIds);

        public static void GetValidSupplementIds(
            GetValidSupplementIdsCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to get valid supplement IDs: Licensing not " +
                            "initialized"),
                    validSupplementIds: null);

                return;
            }

            try
            {
                s_licenseManagerUnity.GetValidSupplementIds(
                    (exception, validSupplementIds) =>
                    {
                        completionCallback(exception, validSupplementIds);
                    });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to get valid supplement IDs: {0}",
                            e.Message),
                        e),
                    validSupplementIds: null);

                return;
            }
        }

        public static IEnumerator GetValidSupplementIdsCoroutineEnumerator(
            GetValidSupplementIdsCompletionFunc completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            GetValidSupplementIds(
                (exception, validSupplementIds) =>
                {
                    completionCallback(exception, validSupplementIds);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void CheckIsUsingZspaceLicensingSystemCompletionFunc(
            Exception exception, bool isUsingZspaceLicensingSystem);

        public static void CheckIsUsingZspaceLicensingSystem(
            CheckIsUsingZspaceLicensingSystemCompletionFunc completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to check is using zSpace licensing system: " +
                            "Licensing not initialized"),
                    isUsingZspaceLicensingSystem: false);

                return;
            }

            try
            {
                s_licenseManagerUnity.CheckIsUsingZspaceLicensingSystem(
                    (exception, isUsingZspaceLicensingSystem) =>
                    {
                        completionCallback(
                            exception, isUsingZspaceLicensingSystem);
                    });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to check is using zSpace licensing " +
                                "system: {0}",
                            e.Message),
                        e),
                    isUsingZspaceLicensingSystem: false);

                return;
            }
        }

        public static IEnumerator
            CheckIsUsingZspaceLicensingSystemCoroutineEnumerator(
                CheckIsUsingZspaceLicensingSystemCompletionFunc
                    completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            CheckIsUsingZspaceLicensingSystem(
                (exception, isUsingZspaceLicensingSystem) =>
                {
                    completionCallback(exception, isUsingZspaceLicensingSystem);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        public delegate void
            GetLastShouldUseLegacyLicensingSystemResultCompletionFunc(
                Exception exception, bool shouldUseLegacyLicensingSystem);

        public static void GetLastShouldUseLegacyLicensingSystemResult(
            GetLastShouldUseLegacyLicensingSystemResultCompletionFunc
                completionCallback)
        {
            if (s_licenseManagerUnity == null)
            {
                completionCallback(
                    new Exception(
                        "Failed to get last should use legacy licensing " +
                            "system result: Licensing not initialized"),
                    shouldUseLegacyLicensingSystem: false);

                return;
            }

            try
            {
                s_licenseManagerUnity
                    .GetLastShouldUseLegacyLicensingSystemResult(
                        (exception, shouldUseLegacyLicensingSystem) =>
                        {
                            completionCallback(
                                exception, shouldUseLegacyLicensingSystem);
                        });
            }
            catch (Exception e)
            {
                completionCallback(
                    new Exception(
                        string.Format(
                            "Failed to get last should use legacy licensing " +
                                "system result: {0}",
                            e.Message),
                        e),
                    shouldUseLegacyLicensingSystem: false);

                return;
            }
        }

        public static IEnumerator
            GetLastShouldUseLegacyLicensingSystemResultCoroutineEnumerator(
                GetLastShouldUseLegacyLicensingSystemResultCompletionFunc
                    completionCallback)
        {
            var completionWaiter = new WaitForCallback();

            GetLastShouldUseLegacyLicensingSystemResult(
                (exception, shouldUseLegacyLicensingSystem) =>
                {
                    completionCallback(
                        exception, shouldUseLegacyLicensingSystem);

                    completionWaiter.SetCallbackCalled();
                });

            yield return completionWaiter;
        }

        //////////////////////////////////////////////////////////////////
        // Private Members
        //////////////////////////////////////////////////////////////////

        private static GameObject s_licenseManagerGameObject = null;
        private static LicenseManagerUnity s_licenseManagerUnity = null;
    }
}
