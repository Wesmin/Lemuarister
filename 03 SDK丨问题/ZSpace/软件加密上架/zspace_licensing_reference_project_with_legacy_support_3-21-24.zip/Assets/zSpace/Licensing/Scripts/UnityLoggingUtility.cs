//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////////

using System;
using UnityEngine;

namespace zSpace.Licensing.Unity
{
    public static class UnityLoggingUtility
    {
        //////////////////////////////////////////////////////////////////
        // Public Methods
        //////////////////////////////////////////////////////////////////

        public static void EmitLicensingLogMessageViaUnityLogger(
            LicensingLogLevel logLevel,
            DateTime timestamp,
            string loggerName,
            string threadId,
            string message)
        {
            string logLevelString;

            LogType unityLogType;

            switch (logLevel)
            {
                case LicensingLogLevel.Error:
                    logLevelString = "Error";
                    unityLogType = LogType.Error;
                    break;

                case LicensingLogLevel.Warning:
                    logLevelString = "Warning";
                    unityLogType = LogType.Warning;
                    break;

                case LicensingLogLevel.Info:
                    logLevelString = "Info";
                    unityLogType = LogType.Log;
                    break;

                case LicensingLogLevel.Debug:
                    logLevelString = "Debug";
                    unityLogType = LogType.Log;
                    break;

                case LicensingLogLevel.Verbose:
                    logLevelString = "Verbose";
                    unityLogType = LogType.Log;
                    break;

                default:
                    logLevelString =
                        string.Format("Unknown ({0:G} [{0:D}])", logLevel);
                    unityLogType = LogType.Error;
                    break;
            }

            Debug.unityLogger.LogFormat(
                unityLogType,
                "{0,-7} - {1:yyyy-MM-dd HH:mm:ss.fff} [{2,6}] {3} | {4}",
                logLevelString,
                timestamp,
                threadId,
                loggerName,
                message);
        }
    }
}
