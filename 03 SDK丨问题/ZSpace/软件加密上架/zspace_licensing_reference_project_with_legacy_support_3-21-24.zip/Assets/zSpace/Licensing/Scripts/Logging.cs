//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////////

using System;

namespace zSpace.Licensing.Unity
{
    /// <summary>
    /// Enum defining the possible log levels for licensing log messages.
    /// </summary>
    public enum LicensingLogLevel : int
    {
        Error = 10,
        Warning = 20,
        Info = 30,
        Debug = 40,
        Verbose = 50,
    }

    /// <summary>
    /// Delegate for licensing log message callbacks.
    /// </summary>
    /// <param name="logLevel">
    /// The log message log level.
    /// </param>
    /// <param name="timestamp">
    /// The log message timestamp.
    /// </param>
    /// <param name="loggerName">
    /// The name of the logger that emitted the log message.
    /// </param>
    /// <param name="threadId">
    /// The ID of the thread that the log message was emitted from.
    /// </param>
    /// <param name="message">
    /// The log message text.
    /// </param>
    public delegate void LicensingLogFunc(
        LicensingLogLevel logLevel,
        DateTime timestamp,
        string loggerName,
        string threadId,
        string message);
}
