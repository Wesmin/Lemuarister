//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2023 zSpace, Inc.  All Rights Reserved.
//
//////////////////////////////////////////////////////////////////////////////

using System;
using System.IO;
using System.Text;

using UnityEngine;

namespace zSpace.Licensing.Unity
{
    public class ApplicationLicensingConfiguration
    {
        //////////////////////////////////////////////////////////////////
        // Public Properties
        //////////////////////////////////////////////////////////////////

        public LicensingLogFunc LogFunc { get; private set; }

        public LicensingLogLevel LogLevel { get; private set; }

        public string[] ApplicationActiveModeIds { get; private set; }

        public string[] ApplicationActiveSupplementIds { get; private set; }

        public string ApplicationVersion { get; private set; }

        public byte[] ApplicationLicensingSecretBytes { get; private set; }

        public byte[] ApplicationLicensingDetailsBytes { get; private set; }

        public string Locale { get; private set; }

        public string ApplicationUserFriendlyNameForLocale { get; private set; }

        public IntPtr? ApplicationMainWindowHandle { get; private set; }

        public bool ShouldEnableLegacyLicensingSystemSupport
            { get; private set; }

        //////////////////////////////////////////////////////////////////
        // Public Methods
        //////////////////////////////////////////////////////////////////

        public ApplicationLicensingConfiguration()
        {
            this.SetUnityLogFunc();

            this.LogLevel = LicensingLogLevel.Info;

            this.ApplicationActiveModeIds = null;

            this.ApplicationActiveSupplementIds = new string[] { };

            this.ApplicationVersion = null;

            this.ApplicationLicensingSecretBytes = null;

            this.ApplicationLicensingDetailsBytes = null;

            this.Locale = null;

            this.ApplicationUserFriendlyNameForLocale = null;

            this.SetUnityApplicationMainWindowHandle();

            this.ShouldEnableLegacyLicensingSystemSupport = false;
        }

        public ApplicationLicensingConfiguration SetLogFunc(
            LicensingLogFunc logFunc)
        {
            this.LogFunc = logFunc;

            return this;
        }

        public ApplicationLicensingConfiguration SetUnityLogFunc()
        {
            this.LogFunc =
                UnityLoggingUtility.EmitLicensingLogMessageViaUnityLogger;

            return this;
        }

        public ApplicationLicensingConfiguration SetLogLevel(
            LicensingLogLevel logLevel)
        {
            this.LogLevel = logLevel;

            return this;
        }

        public ApplicationLicensingConfiguration SetApplicationActiveModeId(
            string applicationActiveModeId)
        {
            this.ApplicationActiveModeIds =
                new string[] { applicationActiveModeId };

            return this;
        }

        public ApplicationLicensingConfiguration SetApplicationActiveModeIds(
            string[] applicationActiveModeIds)
        {
            this.ApplicationActiveModeIds = applicationActiveModeIds;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationActiveSupplementIds(
                string[] applicationActiveSupplementIds)
        {
            this.ApplicationActiveSupplementIds =
                applicationActiveSupplementIds;

            return this;
        }

        public ApplicationLicensingConfiguration SetApplicationVersion(
            string applicationVersion)
        {
            this.ApplicationVersion = applicationVersion;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationLicensingSecret(
                string applicationLicensingSecret)
        {
            var ut8Encoding = new UTF8Encoding(
                encoderShouldEmitUTF8Identifier: false,
                throwOnInvalidBytes: true);

            this.ApplicationLicensingSecretBytes =
                ut8Encoding.GetBytes(applicationLicensingSecret);

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationLicensingSecretBytes(
                byte[] applicationLicensingSecretBytes)
        {
            this.ApplicationLicensingSecretBytes =
                applicationLicensingSecretBytes;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationLicensingDetailsFromFile(
                string applicationLicensingDetailsFilePath)
        {
            this.ApplicationLicensingDetailsBytes =
                File.ReadAllBytes(applicationLicensingDetailsFilePath);

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationLicensingDetailsFromStreamingAssetsFile(
                string applicationLicensingDetailsFileStreamingAssetsPath)
        {
            var applicationLicensingDetailsFilePath = Path.Combine(
                Application.streamingAssetsPath,
                applicationLicensingDetailsFileStreamingAssetsPath);

            this.SetApplicationLicensingDetailsFromFile(
                applicationLicensingDetailsFilePath);

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationLicensingDetailsBytes(
                byte[] applicationLicensingDetailsBytes)
        {
            this.ApplicationLicensingDetailsBytes =
                applicationLicensingDetailsBytes;

            return this;
        }

        public ApplicationLicensingConfiguration SetLocale(
            string locale, string applicationUserFriendlyNameForLocale)
        {
            this.Locale = locale;
            this.ApplicationUserFriendlyNameForLocale =
                applicationUserFriendlyNameForLocale;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetApplicationMainWindowHandle(
                IntPtr applicationMainWindowHandle)
        {
            this.ApplicationMainWindowHandle = applicationMainWindowHandle;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetUnityApplicationMainWindowHandle()
        {
            this.ApplicationMainWindowHandle = null;

            return this;
        }

        public ApplicationLicensingConfiguration
            SetLegacyLicensingSystemSupportEnabled(
                bool shouldEnableLegacyLicensingSystemSupport)
        {
            this.ShouldEnableLegacyLicensingSystemSupport =
                shouldEnableLegacyLicensingSystemSupport;

            return this;
        }
    }
}
